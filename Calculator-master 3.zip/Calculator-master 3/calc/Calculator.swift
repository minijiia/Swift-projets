//
//  Calculator.swift
//  calc
//
//  Created by Jacktator on 31/3/20.
//  Copyright © 2020 UTS. All rights reserved.
//

import Foundation

class Calculator {
    
    /// For multi-step calculation, it's helpful to persist existing result
    var currentResult = 0;
    /// Perform Addition
    ///
    /// - Author: Jacktator
    /// - Parameters:
    ///   - no1: First number
    ///   - no2: Second number
    /// - Returns: The addition result
    ///
    /// - Warning: The result may yield Int overflow.
    /// - SeeAlso: https://developer.apple.com/documentation/swift/int/2884663-addingreportingoverflow
    func add(no1: Int, no2: Int) -> String{
        return String(no1 + no2);
    }
    func mins(no1: Int,no2: Int)-> String {
        return String(no1 - no2)
    }
    func multi(no1: Int,no2: Int)-> String {
        return String(no1 * no2);
    }
    func divide(no1: Int,no2: Int)-> String {
        return String(no1 / no2);
    }
    func percent(no1: Int,no2: Int)-> String {
        return String(no1 % no2);
    }
    
    
    func calculate(args: [String]) -> String {
        // Todo: Calculate Result from the arguments. Replace dummyResult with your actual result;
      
        var i = 1
        var num = args
        for _ in stride(from: num.count, through: 1,by: -2) {
            /* if(condition){
             可以包含switch, function
             }
             */
            if(num[i] == "x" || num[i] == "/" || num[i] == "%")
            {
                /*condition:
                 */
                switch num[i] {
                case "x":
                    //
                    let a = multi(no1: Int(num[i-1])!, no2: Int(num[i+1])!);
                    //
                    num[i] = String(a)
                    num.remove(at: i-1)
                    num.remove(at: i)
                case "/":
                    let a = divide(no1: Int(num[i-1])!, no2: Int(num[i+1])!);
                    num[i] = String(a)
                    num.remove(at: i-1)
                    num.remove(at: i)
                case "%":
                    let a = percent(no1: Int(num[i-1])!, no2: Int(num[i+1])!);
                    num[i] = String(a)
                    num.remove(at: i-1)
                    num.remove(at: i)
                default:
                    //
                    exit(1);
                }
                
                
                
                }
            
        }
        let result = num[1];

        return result
        
    }
}

